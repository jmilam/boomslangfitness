'use strict';
// Configuration for Jasmine or other components related to the specs
jasmine.getFixtures().fixturesPath = 'base/test/fixtures';
jasmine.DEFAULT_TIMEOUT_INTERVAL = 60000;
